export class Trains {
  id: string;
  name: string;
  source: string;
  destination: string;
  price: number;

  constructor() {}
}
