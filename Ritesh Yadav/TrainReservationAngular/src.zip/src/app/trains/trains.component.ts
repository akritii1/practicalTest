import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Trains } from '../trains';

@Component({
  selector: 'app-trains',
  templateUrl: './trains.component.html',
  styleUrls: ['./trains.component.css'],
})
export class TrainsComponent implements OnInit {
  Train: any = [];
  train: Trains;
  errorMsg: string;
  constructor(private httpClient: HttpClient) {}

  ngOnInit(): void {
    this.httpClient.get('assets/data/trains.json').subscribe(
      (data) => {
        console.log(data);
        this.Train = data;
      },
      (error) => {
        console.log('error has occured');
        this.errorMsg = error.message;
        alert(this.errorMsg);
      }
    );
  }

  id: string;
  SearchById() {
    if (this.id != '') {
      this.Train = this.Train.filter((res) => {
        return res.id.toLocaleLowerCase().match(this.id.toLocaleLowerCase());
      });
    } else if (this.id == '') {
      this.ngOnInit();
    }
  }
}
