export class Pass {
  id: string;
  name: string;
  age: number;
  gender: string;
  mobile: number;

  constructor() {}
}
