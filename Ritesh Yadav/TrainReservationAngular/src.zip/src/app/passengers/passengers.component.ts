import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Pass } from '../pass';

@Component({
  selector: 'app-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.css'],
})
export class PassengersComponent implements OnInit {
  Passenger: any = [];
  passenger: Pass;
  errorMsg: string;

  constructor(private httpClient: HttpClient) {}

  ngOnInit(): void {
    this.httpClient.get('assets/data/passengers.json').subscribe(
      (data) => {
        console.log(data);
        this.Passenger = data;
      },
      (error) => {
        console.log('error has occured');
        this.errorMsg = error.message;
        alert(this.errorMsg);
      }
    );
  }
  id: string;
  SearchById() {
    if (this.id != '') {
      this.Passenger = this.Passenger.filter((res) => {
        return res.id.toLocaleLowerCase().match(this.id.toLocaleLowerCase());
      });
    } else if (this.id == '') {
      this.ngOnInit();
    }
  }
}
