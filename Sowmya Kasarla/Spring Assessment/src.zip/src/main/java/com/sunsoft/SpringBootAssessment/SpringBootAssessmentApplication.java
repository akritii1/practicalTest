package com.sunsoft.SpringBootAssessment;

import org.springframework.boot.SpringBootApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAssessmentApplication {

	public static void main(String[] args) {
		SpringBootApplication.run(SpringBootAssessmentApplication.class, args);
	}

}
