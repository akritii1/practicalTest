package com.sunsoft.SpringBootAssessment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.SpringBootAssessment.dao.EmployeeDao;
import com.sunsoft.SpringBootAssessment.model.EmployeeData;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@RequestMapping("/insert")
	public String insertData() {
		EmployeeData emp1=new EmployeeData();
		emp1.setId(1);
		emp1.setFirstname("Sowmya");
		emp1.setLastname("Kasarla");
		emp1.setDept("IBGT");
		emp1.setDesi("Associate");
		emp1.setSalary(50000);
		
		EmployeeData emp2=new EmployeeData();
		emp2.setId(2);
		emp2.setFirstname("Sushma");
		emp2.setLastname("Netha");
		emp2.setDept("MOT");
		emp2.setDesi("Manager");
		emp2.setSalary(90000);
		
		
		EmployeeData emp3=new EmployeeData();
		emp3.setId(3);
		emp3.setFirstname("Keerthi");
		emp3.setLastname("Kasarla");
		emp3.setDept("ITT");
		emp3.setDesi("Associate");
		emp3.setSalary(50000);
		
		
		employeeDao.insertData(emp1);
		employeeDao.insertData(emp2);
		employeeDao.insertData(emp3);
		
		return "Data inserted";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id) {
		employeeDao.deleteEmployee(id);
		return "Deleted successfully";
	}
	
	@RequestMapping("/update/{id}")
	public String updateData(@PathVariable ("id") int id) {
		employeeDao.updateEmployee("Updated firstName", id);
		
		return "Updated Successfully";
	}
	
	@RequestMapping("/employee/{id}")
	public EmployeeData employeById(@PathVariable ("id") int id){
		return employeeDao.employeeById(id);
	}
	
	@RequestMapping("/displayAll")
	public List<EmployeeData> displayData(){
		List<EmployeeData> employee=employeeDao.displayAll();
		
		return employee;
	}

}
