package com.sunsoft.SpringAssessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
