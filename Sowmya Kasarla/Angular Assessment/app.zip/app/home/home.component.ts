import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  items: Array<any> = []

  constructor() {
    this.items = [
      { name: 'assets/img1.jpg' },
      { name: 'assets/img2.jpg' },
     
      { name: 'assets/img3.jpg' },
      
      { name: 'assets/img4.jpg' }
     
      
    ]
   }

  ngOnInit(): void {
  }

}
