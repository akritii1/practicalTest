import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.css']
})
export class PassengerComponent implements OnInit {

  selected: string = '';
  passenger:any=[]
  i:number=0;
  constructor() { }
  passengers=[
    {id:""},
    {id:"1",name:"Sowmya",mail:"sowmya@gmail.com",age:21},
    {id:"2",name:"Sushma",mail:"sushma@gmail.com",age:22},
    {id:"3",name:"Krithi",mail:"krithi@gmail.com",age:25},
    {id:"4",name:"Priya",mail:"priya@gmail.com",age:60},
    {id:"5",name:"Keerthi",mail:"keerthi9@gmail.com",age:56},
    {id:"6",name:"Jahnavi",mail:"janu@gmail.com",age:12},
    {id:"7",name:"Veena",mail:"veena7@gmail.com",age:32}
  ]
  selectChangeHandler (event: any) {
   
    //update the ui
    this.selected = event.target.value;
    if(this.selected!==""){
    for(var i=0;i<this.passengers.length;i++){
      if(this.passengers[i].id==this.selected){
        this.passenger[0]=this.passengers[i];
      }
    }}
    else{
      this.passenger=this.passengers
    }
  
  }

  ngOnInit(): void {
  }

}
