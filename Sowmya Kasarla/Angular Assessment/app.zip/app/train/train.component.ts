import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-train',
  templateUrl: './train.component.html',
  styleUrls: ['./train.component.css']
})
export class TrainComponent implements OnInit {
  selected: string = '';
 
  train:any=[]
 i:number=0;

  constructor() { }
  trains=[
    {trainno:"",from:"",to:""},
    {trainno:"12645",name:"rajdhani Express",from:"Hyderabad",to:"Kolkota"},
    {trainno:"54685",name:"Duronto Express",from:"Chennai",to:"Mumbai"},
    {trainno:"84565",name:"Shatabdi Express",from:"Delhi",to:"Goa"},
    {trainno:"86245",name:"Jan Shatabdi Express",from:"Jammu & Kashir",to:"Kanyakumari"},
    {trainno:"94563",name:"Sampark Kranti Express",from:"Agra",to:"Assam"},
    {trainno:"86245",name:"Garib Rath Express",from:"Jammu & Kashir",to:"Kanyakumari"},
    {trainno:"95682",name:"Humsafar Express",from:"Goa",to:"Vizag"},
    {trainno:"86245",name:"Kavi Guru Express",from:"Srinagar",to:"Kerala"},
    {trainno:"94563",name:" Rajya Rani Express",from:"Dibrugarh",to:"Kanyakumari"}
   
  ]
  selectChangeHandler (event: any) {
    if(this.selected=="")
    {

    }
    //update the ui
    this.selected = event.target.value;
    if(this.selected!==""){
    for(var i=0;i<this.trains.length;i++){
      if(this.trains[i].trainno==this.selected){
        this.train[0]=this.trains[i];
      }
    }}
    else{
      this.train=this.trains
    }
  }


  ngOnInit(): void {
  }

}
