import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TrainComponent } from './train/train.component';
import { PassengerComponent } from './passenger/passenger.component';
import { Ng2CarouselamosModule } from 'ng2-carouselamos';
const appRoutes : Routes = [
  {path: 'home',
   component: HomeComponent
  },
  {path: 'train',
   component: TrainComponent
  },
  {path: 'passenger',
   component: PassengerComponent
  },
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TrainComponent,
    PassengerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng2CarouselamosModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
