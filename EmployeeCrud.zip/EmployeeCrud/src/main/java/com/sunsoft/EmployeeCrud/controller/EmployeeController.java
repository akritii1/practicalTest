package com.sunsoft.EmployeeCrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.EmployeeCrud.dao.EmployeeDao;
import com.sunsoft.EmployeeCrud.model.EmployeeData;

//import com.sunsoft.MyFirstDBBoot1.dao.StudentDao;
//import com.sunsoft.MyFirstDBBoot1.model.StudentData;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeDao empDao;
	
	@RequestMapping("/insert")
	public String insert() {
		EmployeeData obj=new EmployeeData();
		obj.setId(10);
		obj.setName("Roshni");
		obj.setDept("Marketing");
		obj.setSalary(10000);
		EmployeeData obj1=new EmployeeData();
		obj1.setId(41);
		obj1.setName("Aakanksha");
		obj1.setDept("Finance");
		obj1.setSalary(8000);
		EmployeeData obj2=new EmployeeData();
		obj2.setId(18);
		obj2.setName("Mayank");
		obj2.setDept("IT");
		obj2.setSalary(10000);
		System.out.println("Inside insert func of controller");
		empDao.insert(obj1);
		empDao.insert(obj);
		empDao.insert(obj2);
		return "Data Successfully inserted";
	}
	@RequestMapping("/display")
	public List<EmployeeData> display(){
		List<EmployeeData> ls=empDao.display();
		return ls;
	}	
	@RequestMapping("/update/{id1}")
	public String update(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("dept") String dept,@RequestParam("salary") int salary,@PathVariable("id1") int id1)
	{ 
		EmployeeData obj=new EmployeeData();
		obj.setId(id);
		obj.setName(name);
		obj.setDept(dept);
		obj.setSalary(salary);
		empDao.update(obj);
		return "Updated Successfully";
		
	}
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		empDao.delete(id);
		return "Deleted Successfully";
	}
}
