package com.sunsoft.EmployeeCrud.repository;

import org.springframework.data.repository.CrudRepository;

import com.sunsoft.EmployeeCrud.model.EmployeeData;

//import com.sunsoft.MyFirstDBBoot1.model.StudentData;

public interface EmployeeRepository extends CrudRepository<EmployeeData, Integer>{

}
