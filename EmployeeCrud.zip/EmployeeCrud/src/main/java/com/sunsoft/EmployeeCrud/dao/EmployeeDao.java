package com.sunsoft.EmployeeCrud.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.EmployeeCrud.model.EmployeeData;
//import com.sunsoft.MyFirstDBBoot1.model.StudentData;
//import com.sunsoft.MyFirstDBBoot1.repository.StudentRepository;
import com.sunsoft.EmployeeCrud.repository.EmployeeRepository;

@Service
public class EmployeeDao {
	@Autowired
	EmployeeRepository empRepository;
	public void insert(EmployeeData obj) {
		empRepository.save(obj);
	}
	public List<EmployeeData> display(){
		List<EmployeeData> ls=(List<EmployeeData>) empRepository.findAll();
		return ls;
	}
	public void update(EmployeeData obj) {
		if(empRepository.existsById(obj.getId())) {
		empRepository.save(obj);
		}
	}
	public void delete(int id) {
		empRepository.deleteById(id);
	 
	}
}
