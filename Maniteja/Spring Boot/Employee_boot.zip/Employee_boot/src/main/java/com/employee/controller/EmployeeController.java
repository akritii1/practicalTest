package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.dao.EmployeeDao;
import com.employee.model.EmployeeData;
//import com.example.demoBoot.model.StudentData;
import com.example.demoBoot.model.StudentData;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@RequestMapping("/insert")
	public String insertRecord() {
			
		EmployeeData emp = new EmployeeData();
		emp.setId(200);
		emp.setName("Rohan");
		emp.setDept("MOT");
		emp.setage(22);
		emp.setSalary(10000);
		
		
		EmployeeData emp1 = new EmployeeData();
		emp1.setId(202);
		emp1.setName("Rahul");
		emp1.setDept("CBGT");
		emp1.setage(20);
		emp1.setSalary(10000);

		employeeDao.insertData(emp);
		employeeDao.insertData(emp1);
		
		return "Records inserted";
		
	}
	
	@RequestMapping ("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id)
	{
		employeeDao.deleteRecord(id);
		return "Record deleted successfully";
	}
//	@GetMapping("/all")
//	public List<StudentData> displayData(){
//		List<StudentData> studentList = studentDao.displayAll();
//		return studentList;
//	}
	@RequestMapping("/update")
	public String updateRecord()
	{
		EmployeeData emp = new EmployeeData();
		emp.setId(200);
		emp.setName("Moseen");
		emp.setDept("Tech");
		emp.setSalary(60000);
		
		employeeDao.updateData(emp);
		return "Data updated succesfully";
	}
//	@PutMapping("/student")
//	public void updateData(@RequestBody StudentData studentData) {
//		studentDao.insertData(studentData);
//	}
//	
//	@PostMapping("/student")
//	public <T> ResponseEntity<T> insert(@RequestBody StudentData studentData) {
//		  StudentData studentData1 = new StudentData(); studentData1.setId(2);
//		  studentData1.setName("Juliet"); studentData1.setDept("MEC");
//		  studentData1.setMarks(60);
//		 
//	
//	studentDao.insertData(studentData);
//	return new ResponseEntity<T>(HttpStatus.CREATED);
//	
//	}
	@RequestMapping ("/displayAll")
	public List<EmployeeData> displayData() {
		List<EmployeeData> empList = employeeDao.displayAll();
		return empList;
	}


}
