package com.example.demoBoot.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demoBoot.model.StudentData;

public interface StudentRepository extends CrudRepository<StudentData, Integer>{

}
