package com.example.demoBoot.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employeeData")
public class StudentData {
	@Id
	@Column
	int id;
	
	@Column 
	String name;
	@Column 
	String dept;
	@Column 
	int marks;
	@Column
	String location;
	@Column
	Date doj;
	
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int salary) {
		this.marks = salary;
	}
	@Override
	public String toString() {
		return "StudentData [id=" + id + ", name=" + name + ", dept=" + dept + ", marks=" + marks + ", location="
				+ location + ", doj=" + doj + "]";
	}
	
	
}
