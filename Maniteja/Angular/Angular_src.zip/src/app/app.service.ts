import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import  passengers from './assets/passengers.json';
import trains from './assets/trains.json';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private httpClient: HttpClient) { }

  getPassengersList(){
    return of(passengers);
  }
  getTrainsList(){
    return of(trains);
  }
  
}
