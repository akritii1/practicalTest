import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-trains',
  templateUrl: './trains.component.html',
  styleUrls: ['./trains.component.css']
})
export class TrainsComponent implements OnInit {

  trains: any;
  filteredTrains: any;
  selectedTID = "";

  constructor(private appService: AppService) { }


  ngOnInit(): void {
    this.displayTrains();
  }

  displayTrains() {
    this.appService.getTrainsList().subscribe(
      response => {
        this.trains = response;
        this.filteredTrains = response;
      }
    )
  }
  filterTrainsList() {
    if (this.selectedTID != "") {
      this.filteredTrains = this.trains.filter(train => train.tid === this.selectedTID);
    }
    else
      this.filteredTrains = this.trains;
  }

}
