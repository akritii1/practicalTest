import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.css']
})
export class PassengersComponent implements OnInit {

  passengers: any;
  filteredPassengers: any;
  selectedPID: "";
  constructor(private appService: AppService) { }

  ngOnInit(): void {
    this.displayPassengers();
  }

  displayPassengers() {
    this.appService.getPassengersList().subscribe(
      response => {
        this.passengers = response;
        this.filteredPassengers = response;
      }
    )
  }

  filterPassengersList() {
    //console.log(this.filteredPassengers = this.passengers.filter(passenger => passenger.pid === id));
    console.log(this.selectedPID);
    if (this.selectedPID != "") {
      this.filteredPassengers = this.passengers.filter(passenger => passenger.pid === this.selectedPID);
      console.log(this.filteredPassengers);
    }
    else
      this.filteredPassengers = this.passengers;
  }

}
