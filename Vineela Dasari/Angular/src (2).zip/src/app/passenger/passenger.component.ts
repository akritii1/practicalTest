import { Component, OnInit } from '@angular/core';
import { Passenger } from '../passenger-info';
import { PassengerinformationService } from '../passengerinformation.service';

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.css']
})
export class PassengerComponent implements OnInit {

  constructor(private pass:PassengerinformationService) { }
  pass1: any[];
  pa:String="";
  ngOnInit(): void {
    this.pass1=this.pass.passenger;
  }

}
