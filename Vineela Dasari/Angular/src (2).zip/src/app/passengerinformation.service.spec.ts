import { TestBed } from '@angular/core/testing';

import { PassengerinformationService } from './passengerinformation.service';

describe('PassengerinformationService', () => {
  let service: PassengerinformationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PassengerinformationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
