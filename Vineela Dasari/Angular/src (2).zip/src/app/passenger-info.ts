export class Passenger{
    id:String;
    name:String;
    age:String;
    gender:String;
    contact:String;
    address:String
    constructor(id:String,
        name:String,
        age:String,
        gender:String,
        contact:String,
        address:String){
            this.id=id;
            this.name=name;
            this.age=age;
            this.gender=gender;
            this.contact=contact;
            this.address=address;
        }

}