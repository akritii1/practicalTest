import { Injectable } from '@angular/core';
import { TrainInfo } from './train-info';

@Injectable({
  providedIn: 'root'
})
export class TraininformationService {

  constructor() { }
  train: TrainInfo[]=[
    {
      train_no:"12345",
      source:"Hyderabad",
      destination:"Banglore",
      departure_time:"12:00 PM(IST)",
      total_seats: "300",
      available_seats:"90"
    },
    {
      train_no:"12485",
      source:"Chennai",
      destination:"Banglore",
      departure_time:"4:00 PM(IST)",
      total_seats: "250",
      available_seats:"50"
    },
    {
      train_no:"12520",
      source:"Mumbai",
      destination:"Kochi",
      departure_time:"3:00 PM(IST)",
      total_seats: "500",
      available_seats:"150"
    },
    {
      train_no:"12400",
      source:"Bhopal",
      destination:"Guntur",
      departure_time:"4:00 PM(IST)",
      total_seats: "250",
      available_seats:"50"
    },
    {
      train_no:"12600",
      source:"Mysore",
      destination:"Guntur",
      departure_time:"5:30 PM(IST)",
      total_seats: "450",
      available_seats:"100"
    },
    {
      train_no:"12850",
      source:"Delhi",
      destination:"Pune",
      departure_time:"2:50 PM(IST)",
      total_seats: "500",
      available_seats:"200"
    },
    {
      train_no:"12999",
      source:"Ahmedabad",
      destination:"Gandhi Nagar",
      departure_time:"11:50 AM(IST)",
      total_seats: "400",
      available_seats:"20"
    },
    {
      train_no:"12888",
      source:"Delhi",
      destination:"Sonipat",
      departure_time:"2:50 PM(IST)",
      total_seats: "140",
      available_seats:"50"
    },
    {
      train_no:"12836",
      source:"Bhuvaneshwar",
      destination:"Hyderabad",
      departure_time:"4:50 PM(IST)",
      total_seats: "500",
      available_seats:"200"
    },
    {
      train_no:"12444",
      source:"Pune",
      destination:"Indore",
      departure_time:"6:50 PM(IST)",
      total_seats: "500",
      available_seats:"140"
    }

  ]
   
  
}
