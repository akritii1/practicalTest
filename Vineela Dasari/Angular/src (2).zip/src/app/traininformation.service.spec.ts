import { TestBed } from '@angular/core/testing';

import { TraininformationService } from './traininformation.service';

describe('TraininformationService', () => {
  let service: TraininformationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TraininformationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
