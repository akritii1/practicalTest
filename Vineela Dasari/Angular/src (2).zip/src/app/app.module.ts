import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { TrainComponent } from './train/train.component';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from './filter.pipe';
import { PassengerComponent } from './passenger/passenger.component';
//import { PasserinformationComponent } from './passerinformation/passerinformation.component';
const appRoute: Routes=[
  {
    path:'train',
    component: TrainComponent
  },
  {
    path:'passenger',
    component: PassengerComponent
  },
  {
    path:'home',
    component: HomeComponent
  },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  
]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TrainComponent,
    FilterPipe,
    PassengerComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoute),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
