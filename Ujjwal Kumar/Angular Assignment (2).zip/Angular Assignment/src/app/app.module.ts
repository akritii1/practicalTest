import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ListComponent } from './list/list.component';
import { PassengersComponent } from './passengers/passengers.component';
import {RouterModule, Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';
import {HttpClientModule}  from '@angular/common/http';
import { ChartComponent } from './chart/chart.component';
import { Chart1Component } from './chart1/chart1.component';
const appRoutes : Routes = [
  {path: 'home',
   component: HomeComponent
  },
  {path: 'list',
   component: ListComponent
  },
  {path: 'passengers',
   component: PassengersComponent
  },
  {path: 'chart',
   component: ChartComponent
  },
  {path: 'chart1',
   component: Chart1Component
  }
  ];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ListComponent,
    PassengersComponent,
    ChartComponent,
    Chart1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
