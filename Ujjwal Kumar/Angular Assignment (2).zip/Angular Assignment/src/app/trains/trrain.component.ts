import { Component, OnInit } from '@angular/core';
import {Book} from './train_book';
import {HttpClient}  from '@angular/common/http'; 
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
   Books: any = [];
   book : Book;
   errorMsg : string;
id:string;
constructor(private httpClient : HttpClient){}  

  ngOnInit() {
    this.httpClient.get("assets/data/train_reservation.json"). 
      subscribe (data =>
        {
          console.log(data);
          this.Books = data;              
        }, 
        (error) => 
         {
               console.error ("error has occured");
               this.errorMsg = error.message;
               alert (this.errorMsg);
         }
        );  
  }


  Search(){
    if(this.id != ""){
      this.Books = this.Books.filter(res=>{
        return res.id.toLocaleLowerCase().match(this.id.toLocaleLowerCase());
      });
  
    }else if(this.id != ""){
      this.ngOnInit();
    }
    
  }

}
