export class Book
{
   id:number;
   name:string;
   date:string;
   age:string;
   train_id:string;
   constructor(){}
}