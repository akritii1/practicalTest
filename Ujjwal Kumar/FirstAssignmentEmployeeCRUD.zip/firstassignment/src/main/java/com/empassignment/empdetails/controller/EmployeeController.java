package com.empassignment.empdetails.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empassignment.empdetails.dao.EmployeeDao;
import com.empassignment.empdetails.model.EmployeeData;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@RequestMapping("/insert")
	public String insertData() {
		EmployeeData obj1=new EmployeeData();
		obj1.setId(1);
		obj1.setFirstname("Rajesh");
		obj1.setLastname("Gupta");
		obj1.setSalary(13000);
		
		EmployeeData obj2=new EmployeeData();
		obj2.setId(2);
		obj2.setFirstname("Job");
		obj2.setLastname("Jacob");
		obj2.setSalary(65700);
		
		employeeDao.insertData(obj1);
		employeeDao.insertData(obj2);
		
		return "Data inserted successfully";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id) {
		employeeDao.deleteEmployee(id);
		return "Employee deleted successfully";
	}
	
	@RequestMapping("/update/{id}")
	public String updateData(@PathVariable ("id") int id) {
		employeeDao.updateEmployee("Updated firstName", id);
		
		return "Updated Successfully";
	}
	
	@RequestMapping("/employee/{id}")
	public EmployeeData employeById(@PathVariable ("id") int id){
		return employeeDao.employeeById(id);
	}
	
	@RequestMapping("/displayAll")
	public List<EmployeeData> displayData(){
		List<EmployeeData> employeeList=employeeDao.displayAll();
		
		return employeeList;
	}

}
