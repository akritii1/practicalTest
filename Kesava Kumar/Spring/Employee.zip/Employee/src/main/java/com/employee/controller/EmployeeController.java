package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.dao.EmployeeDao;
import com.employee.model.EmployeeData;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@RequestMapping("/insert")
	public String insertRecord() {
		
		EmployeeData empObj = new EmployeeData();
		empObj.setId(1);
		empObj.setName("Kesava");
		empObj.setDept("Tech");
		empObj.setSalary(880000);
		
		
		EmployeeData empObj1 = new EmployeeData();
		empObj1.setId(2);
		empObj1.setName("Chandra");
		empObj1.setDept("Tech");
		empObj1.setSalary(8880000);
		
		EmployeeData empObj2 = new EmployeeData();
		empObj1.setId(3);
		empObj1.setName("Suresh");
		empObj1.setDept("CSE");
		empObj1.setSalary(980000);
		
		employeeDao.insertData(empObj);
		employeeDao.insertData(empObj1);
		employeeDao.insertData(empObj2);
		
		return "Employee records inserted";
		
	}
	
	@RequestMapping ("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id)
	{
		employeeDao.deleteRecord(id);
		return "Employee Record deleted successfully";
	}

	@RequestMapping("/update")
	public String updateRecord()
	{
		EmployeeData empObj3 = new EmployeeData();
		empObj3.setId(3);
		empObj3.setName("Suresh Varma");
		empObj3.setDept("CSE");
		empObj3.setSalary(980000);
		
		employeeDao.updateData(empObj3);
		return "Record updated succesfully";
	}
	
	@RequestMapping ("/displayAll")
	public List<EmployeeData> displayData() {
		List<EmployeeData> empList = employeeDao.displayAll();
		return empList;
	}
	
	

}
