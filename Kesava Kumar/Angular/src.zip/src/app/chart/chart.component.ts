import { Component, OnInit } from '@angular/core';
import * as CanvasJS from '../../canvasjs.min';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    let chart = new CanvasJS.Chart("chartContainer", {
      theme: "light2",
      animationEnabled: true,
      exportEnabled: true,
      title:{
        text: "PASSENGERS VS TRAIN OCCUPIED"
      },
      data: [{
        type: "pie",
        showInLegend: true,
        toolTipContent: "<b>{name}</b>: ${y} (#percent%)",
        indexLabel: "{name} - #percent%",
        dataPoints: [
          { y: 450, name: "DNR BJU MEMU SPL" },
          { y: 120, name: "GAYA PATNA MEMU" },
          { y: 300, name: "BTI SOG SPECIAL" },
          { y: 800, name: "BQA VSU MEMU PASS" },
          { y: 150, name: "VSU BQA MEMU PASS" },
          { y: 150, name: "LGL RHA EMU"},
          { y: 250, name: "SBRM AGTL DMU SPL" }
        ]
      }]
    });
      
    chart.render();
  }

}
