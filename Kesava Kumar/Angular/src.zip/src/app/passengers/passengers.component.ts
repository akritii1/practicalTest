import { Component, OnInit } from '@angular/core';
import {Book} from './passengers_book';
import {HttpClient}  from '@angular/common/http'; 
@Component({
  selector: 'app-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.css']
})
export class PassengersComponent implements OnInit {
  Books: any = [];
     book : Book;
     errorMsg : string;
  id:string;
  constructor(private httpClient : HttpClient){}  
  
    ngOnInit() {
      this.httpClient.get("assets/data/passenger_book.json").
        subscribe (data =>
          {
            console.log(data);
            this.Books = data;              
          }, 
          (error) => 
           {
                 console.error ("error has occured");
                 this.errorMsg = error.message;
                 alert (this.errorMsg);
           }
          );  
    }
  
  
    Search(){
      if(this.id != ""){
        this.Books = this.Books.filter(res=>{
          return res.id.toLocaleLowerCase().match(this.id.toLocaleLowerCase());
        });
    
      }else if(this.id != ""){
        this.ngOnInit();
      }
      
    }
}
