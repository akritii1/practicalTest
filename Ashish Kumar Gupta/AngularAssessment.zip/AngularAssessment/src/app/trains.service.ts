import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TrainsService {
  trains: any = [];
  constructor() {}

  filterNum(num: number): any[] {
    var temp = [];
    this.trains.forEach((element) => {
      if ((element.train + '').includes(num + ''))
        temp.push(Object.assign({}, element));
    });
    return temp;
  }
}
