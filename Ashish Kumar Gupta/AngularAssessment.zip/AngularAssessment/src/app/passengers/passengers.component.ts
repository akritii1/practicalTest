import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { PassengersService } from '../passengers.service';

@Component({
  selector: 'app-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.css'],
})
export class PassengersComponent implements OnInit {
  id: number;
  passengers: any = [];

  constructor(
    private httpClient: HttpClient,
    private passengerService: PassengersService
  ) {}

  ngOnInit(): void {
    this.httpClient.get('../assets/data/passengers.json').subscribe((data) => {
      this.passengers = data;
      this.passengerService.passengers = data;
    });
  }

  filterById() {
    if (this.id == null) this.passengers = this.passengerService.passengers;
    else this.passengers = this.passengerService.filterId(this.id);
  }
}
