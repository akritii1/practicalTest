import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PassengersService {
  passengers: any = [];

  constructor() {}

  filterId(id: number): any[] {
    var temp = [];
    this.passengers.forEach((element) => {
      if ((element.id + '').includes(id + ''))
        temp.push(Object.assign({}, element));
    });

    return temp;
  }
}
