import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { TrainsService } from '../trains.service';

@Component({
  selector: 'app-trains',
  templateUrl: './trains.component.html',
  styleUrls: ['./trains.component.css'],
})
export class TrainsComponent implements OnInit {
  trains: any = [];
  num: number;

  constructor(
    private trainservice: TrainsService,
    private httpClient: HttpClient
  ) {}

  ngOnInit(): void {
    this.httpClient.get('../assets/data/trains.json').subscribe((data) => {
      this.trains = data;
      this.trainservice.trains = data;
    });
  }

  filterByNum() {
    if (this.num == null) this.trains = this.trainservice.trains;
    else this.trains = this.trainservice.filterNum(this.num);
  }
}
