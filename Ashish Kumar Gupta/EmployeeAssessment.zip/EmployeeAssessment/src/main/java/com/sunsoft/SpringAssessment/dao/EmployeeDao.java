package com.sunsoft.SpringAssessment.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.SpringAssessment.model.EmployeeData;
import com.sunsoft.SpringAssessment.repository.EmployeeRepository;

@Service
public class EmployeeDao {
	
	@Autowired
	EmployeeRepository employeeRepository;
	public void insertData(EmployeeData employeeObj) {
		employeeRepository.save(employeeObj);
	}
	
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}
	
	public List<EmployeeData> displayAll(){
		List<EmployeeData> employeeList=(List<EmployeeData>)employeeRepository.findAll();
		return employeeList;
	}
	
	public EmployeeData employeeById(Integer id) {
		EmployeeData employee=employeeRepository.findById(id).get();
		return employee;
	}
	
	public void updateEmployee(String firstName,int id) {
		EmployeeData employee=employeeRepository.findById(id).get();
		employee.setFirstname(firstName);
		
		employeeRepository.save(employee);
	}

}
