import { TrainsService } from './trains.service';
import { Train } from './train.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trains',
  templateUrl: './trains.component.html',
  styleUrls: ['./trains.component.css']
})
export class TrainsComponent implements OnInit {

  constructor(private trainList: TrainsService) { }
  str = '';
  tList: Train[];
  ngOnInit(): void {
    this.tList = this.trainList.train;
  }

}
