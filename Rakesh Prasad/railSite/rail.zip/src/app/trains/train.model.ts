export class Train{
    public trainNo: string;
    public src: string;
    public dest: string;
    public depTime: string;
    constructor(trainNo: string, src: string, dest: string, deptTime: string) {
        this.trainNo = trainNo;
        this.src = src;
        this.dest = dest;
        this.depTime = deptTime;
    }
}