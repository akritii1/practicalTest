import { Injectable } from '@angular/core';
import { Train } from './train.model';
@Injectable({
  providedIn: 'root'
})
export class TrainsService {

  constructor() { }
  train: Train[] = [
    {
    trainNo: '5555432',
    src: 'Varanasi',
    dest: 'New Delhi',
    depTime: '17:00 IST'
  },
  {
    trainNo: '553432',
    src: 'Varanasi',
    dest: 'Hyderabad',
    depTime: '15:00 IST'
  },
  {
    trainNo: '565432',
    src: 'Kanpur',
    dest: 'Mumbai',
    depTime: '11:00 IST'
  },
];
}
