export class Passenger{
    public name: string;
    public id: string;
    public age: number;
    public gender: string;
    public address: string;
constructor(id: string, name: string, age: number, gender: string, address: string){
    this.name = name;
    this.age = age;
    this.id = id;
    this.gender = gender;
    this.address = address;
    }
}