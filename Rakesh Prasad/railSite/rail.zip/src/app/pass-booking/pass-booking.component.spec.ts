import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassBookingComponent } from './pass-booking.component';

describe('PassBookingComponent', () => {
  let component: PassBookingComponent;
  let fixture: ComponentFixture<PassBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
