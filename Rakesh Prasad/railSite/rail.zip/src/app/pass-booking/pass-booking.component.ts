import { PassengerService } from './passenger.service';
import { Component, OnInit } from '@angular/core';
import { Passenger } from './passenger.model';
@Component({
  selector: 'app-pass-booking',
  templateUrl: './pass-booking.component.html',
  styleUrls: ['./pass-booking.component.css']
})
export class PassBookingComponent implements OnInit {

  constructor(private passList: PassengerService) { }
  str = '';
  pList: Passenger[];
  ngOnInit(): void {
    this.pList = this.passList.passenger;
  }

}
