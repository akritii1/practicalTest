import { Passenger } from './passenger.model';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PassengerService {

  constructor() { }
  passenger: Passenger[]= [
    {
      id: "12",
      name: "Suneel",
      age: 30,
      gender: "Male",
      address: "Hyderabad"
    },
    {
      id: "20",
      name: "Mahesh",
      age: 25,
      gender: "Male",
      address: "Banglore"
    },
    {
      id: "13",
      name: "Kalpana",
      age: 22,
      gender: "Female",
      address: "Chennai"
    },
  ]

}
